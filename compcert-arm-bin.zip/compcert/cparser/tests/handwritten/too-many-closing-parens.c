int main (void)
{
  int x = main());
}
