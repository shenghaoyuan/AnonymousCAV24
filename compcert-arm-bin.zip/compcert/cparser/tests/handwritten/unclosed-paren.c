int main (void)
{
  int y = 7;
  int x = (3 * (2 + x) - y * y;
}
