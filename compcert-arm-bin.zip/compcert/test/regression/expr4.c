/* Warning, not error */

#define NULL ((void *) 0)

int f(int x) { return x == NULL; }
